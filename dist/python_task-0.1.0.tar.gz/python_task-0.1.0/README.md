# Python Task

Publish task as a Python package #[935][]

## Usage

Steps needed to publish [Task][] as a python package.

[935]: https://github.com/go-task/task/issues/935
[Task]: https://taskfile.dev/
