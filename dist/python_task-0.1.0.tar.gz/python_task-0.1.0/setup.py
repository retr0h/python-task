# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['python_task']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'python-task',
    'version': '0.1.0',
    'description': 'Python package to distribute go-task runner',
    'long_description': '# Python Task\n\nPublish task as a Python package #[935][]\n\n## Usage\n\nSteps needed to publish [Task][] as a python package.\n\n[935]: https://github.com/go-task/task/issues/935\n[Task]: https://taskfile.dev/\n',
    'author': 'נυαη נυαηѕση',
    'author_email': 'john@dewey.ws',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
